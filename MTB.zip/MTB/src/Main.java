import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Movie m = new Movie();
        m.getname();
    }
}
    class Movie{
        static Scanner sc = new Scanner(System.in);
        static String [] movieList = {"1-The Transporter", "2-The Expendables",
                "3-Ninja Turtles", "4-Avengers", "5-Spider-Man"};
        public static void getname() {
            String name;
            System.out.println("Enter your name: ");
            name = sc.nextLine();
            System.out.println("Welcome" +name);
            getMovie();
        }
        public static void getMovie(){
            System.out.println("Select the movie from your List: ");
            for(int i=0; i< movieList.length; i++) {
                System.out.println(movieList[i]);
            }
            int choice = sc.nextInt();
            System.out.println("Please select the to Watch: ");
            System.out.println(movieList[choice-1].substring(2,movieList[choice-1].length())); //movie number won't show
            getSeat();
        }
        public static void getSeat(){
            int n;
            System.out.println("How many seat you want have Please Select");
            n = sc.nextInt();
            int [] arr = new int[n];
            System.out.println("Which seat number you want to have Choose it");
            for(int i=0; i<n; i++){
                arr[i] = sc.nextInt();
            }
            int amount = n*50; //one ticket cost is 50
            System.out.println("Total amount to pay: "+amount);
            System.out.println("Please select your Bank To Pay");
            int bank = 1;
            while (bank==1){
                System.out.println("1)Garanti Bank");
                System.out.println("2)Ing Bank");
                System.out.println("3)Yapıkredi Bank");
                System.out.println("4)AK Bank");
                int bak = sc.nextInt();
                switch (bak) {
                    case 1:
                        System.out.println("Welcome to Garanti Bank");
                        break;
                    case 2:
                        System.out.println("Welcome to Ing Bank");
                        break;
                    case 3:
                        System.out.println("Welcome to Yapıkredi Bank");
                        break;
                    case 4:
                        System.out.println("Welcome to AK Bank");
                        break;
                }
                break;
            }
            System.out.println("Enter the amount: ");
            int amountpay = sc.nextInt();
            if (amountpay == amount){
                System.out.println("Your payment is successfully");
                System.out.println("Your seat has been successfully booked");
                System.out.println("Thank you!");
            }
            else {
                System.out.println("Your Payment Is Failure Please Try Again!");
            }
        }
    }
